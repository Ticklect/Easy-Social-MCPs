# Easy Social MCPs — All-in-One

This archive contains the Easy MCP Installer and all four ready-to-use bundles:

- Reddit Easy v0.3.5
- X Easy v0.1.4
- TikTok Easy v0.1.5
- YouTube Easy v0.1.4

It requires Node.js 22 or newer. It does not run `npm install`.

## Use your existing browser login

The `browser-companion` folder in this ZIP allows Reddit, X and YouTube MCPs to use your **already signed-in** Helium, Chrome, Edge, Brave, Vivaldi, Opera or Chromium browser. On Windows, double-click **`browser-companion/connect-windows.cmd`** to start the bridge and enable automatic startup. Load `browser-companion/extension` as an unpacked Chromium extension in your existing browser and enter the displayed pairing code once. The extension reconnects automatically afterwards. Just tell your agent to post using the MCP; a separate login command is not needed. The plugin now fails clearly if it cannot use the current browser. Set `EASY_SOCIAL_BROWSER_MODE=dedicated` explicitly to use an isolated profile instead.

Only one browser can be connected at a time for a given bridge. Firefox and Safari need separate support. TikTok Easy requires a browser already exposing a local CDP debugger; its Playwright backend cannot yet use the page-only companion. See `browser-companion/README.md` for the supported versions, browser limitations and security details.

On Windows, Reddit, X, YouTube and TikTok also scan for compatible already-running local Chromium debuggers with existing social tabs. They use a verified matching browser session when available. Only browsers already exposing a local debugger or explicitly paired through the extension can be reused; ordinary unpaired browser tabs remain inaccessible.

## Install everything

Extract the ZIP, open a terminal in the extracted directory, and run one command:

```text
node install-easy-mcp.mjs --host codex reddit-easy-v0.3.5.mcpb x-easy-v0.1.4.mcpb tiktok-easy-v0.1.5.mcpb youtube-easy-v0.1.4.mcpb
node install-easy-mcp.mjs --host claude reddit-easy-v0.3.5.mcpb x-easy-v0.1.4.mcpb tiktok-easy-v0.1.5.mcpb youtube-easy-v0.1.4.mcpb
node install-easy-mcp.mjs --host both reddit-easy-v0.3.5.mcpb x-easy-v0.1.4.mcpb tiktok-easy-v0.1.5.mcpb youtube-easy-v0.1.4.mcpb
```

Use `--host codex`, `--host claude`, or `--host both`. Restart the selected client after installation. Once your browser companion is paired, prompts such as “Post this to r/SideProject using Reddit Easy” or “Post this on X using X Easy” work without a separate login command.

For TikTok, `tiktok_post` can now verify the current signed-in profile automatically on the first post. Unlike Reddit, X and YouTube, it needs an existing Chromium session that exposes a **full local CDP debugger**. Without that access, direct posting fails without opening QR login; you may use `tiktok_login` explicitly for the dedicated QR profile.

To install only some services, remove the unwanted `.mcpb` filenames from the command. `SHA256SUMS.txt` contains checksums for the installer and all four bundles.

Each included component retains its own license and security documentation inside its MCPB. The all-in-one packaging files are licensed under the repository's `LICENSE`.

All four components now include additional request-safety checks. Their shared and/or local pacing and cooldown limits are deliberately conservative. These browser-session integrations are unofficial; they do not bypass site policies, guarantee uninterrupted access, or prevent account enforcement. In particular, X's automation rules prohibit scripting its website; users seeking authorised automated access should use the official API.

All four MCPs can use a compatible Chromium browser already exposing a loopback CDP port when `EASY_SOCIAL_BROWSER_DEBUG_PORT` is set. Reddit, X and YouTube default to existing-browser-only operation. Ordinary Chromium windows do not expose a debugging port and require the paired companion where supported. TikTok still requires full browser-level CDP access to reuse existing sessions. Browser permissions cannot be silently bypassed, and no cookies are copied from an existing profile.
