import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { withFileLockSync } from "./file-lock.js";

export type AccountStatus = "connecting" | "active" | "logged_out" | "restricted";

export interface LocalAccount {
  id: string;
  country?: string;
  tag?: string;
  status: AccountStatus;
  created_at: string;
  updated_at: string;
  last_connected_at?: string;
  /** Public profile handle used to prevent actions on the wrong browser account. */
  browser_profile_name?: string;
  last_error?: string;
}

export type OperationStatus = "pending" | "running" | "done" | "failed" | "cancelled";

export interface LocalOperation {
  id: string;
  name: string;
  account_id?: string;
  status: OperationStatus;
  input: Record<string, unknown>;
  result?: unknown;
  error?: string;
  error_code?: string;
  created_at: string;
  updated_at: string;
  post_fingerprint?: string;
  owner_pid?: number;
}

export interface StoredMetric {
  account_id: string;
  video_id: string;
  caption: string | null;
  video_url: string | null;
  posted_at: string | null;
  views: number | null;
  likes: number | null;
  comments: number | null;
  privacy: string | null;
  sampled_at: string;
}

interface ActionRecord {
  account_id: string;
  operation: string;
  acted_at: number;
}

interface LocalState {
  version: 1;
  accounts: LocalAccount[];
  operations: LocalOperation[];
  metrics: StoredMetric[];
  actions: ActionRecord[];
  cooldowns?: Record<string, number>;
  post_intents?: Record<string, PostIntentEntry>;
}

const EMPTY_STATE: LocalState = { version: 1, accounts: [], operations: [], metrics: [], actions: [] };

export function dataDir(): string {
  const configured = process.env.TIKTOK_MCP_DATA_DIR;
  return configured ? resolve(configured) : join(homedir(), ".tiktok-mcp");
}

export function profileDir(accountId: string): string {
  const safe = accountId.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
  if (!safe) throw new Error("account_id must contain a letter, number, dot, dash, or underscore");
  const dir = join(dataDir(), "profiles", safe);
  mkdirSync(dir, { recursive: true });
  return dir;
}

function statePath(): string {
  mkdirSync(dataDir(), { recursive: true });
  return join(dataDir(), "state.json");
}

function readState(): LocalState {
  const path = statePath();
  if (!existsSync(path)) return structuredClone(EMPTY_STATE);
  const parsed = JSON.parse(readFileSync(path, "utf8")) as Partial<LocalState>;
  return {
    version: 1,
    accounts: Array.isArray(parsed.accounts) ? parsed.accounts : [],
    operations: Array.isArray(parsed.operations) ? parsed.operations : [],
    metrics: Array.isArray(parsed.metrics) ? parsed.metrics : [],
    actions: Array.isArray(parsed.actions) ? parsed.actions : [],
    cooldowns: parsed.cooldowns && typeof parsed.cooldowns === "object" ? parsed.cooldowns : {},
    post_intents: parsed.post_intents && typeof parsed.post_intents === "object" ? parsed.post_intents : {},
  };
}

function writeState(state: LocalState): void {
  const path = statePath();
  const next = `${path}.${process.pid}.next`;
  writeFileSync(next, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
  renameSync(next, path);
}

function update(mutator: (state: LocalState) => void): void {
  withFileLockSync(join(dataDir(), "locks", "state.lock"), () => {
    const state = readState();
    mutator(state);
    writeState(state);
  });
}

export function upsertAccount(input: Pick<LocalAccount, "id" | "status"> & Partial<LocalAccount>): LocalAccount {
  let output!: LocalAccount;
  update((state) => {
    const now = new Date().toISOString();
    const existing = state.accounts.find((account) => account.id === input.id);
    if (existing) {
      Object.assign(existing, input, { updated_at: now });
      output = { ...existing };
    } else {
      const created: LocalAccount = { ...input, created_at: now, updated_at: now };
      state.accounts.push(created);
      output = { ...created };
    }
  });
  return output;
}

export function getAccount(id: string): LocalAccount | undefined {
  return readState().accounts.find((account) => account.id === id);
}

export function listAccounts(tag?: string): LocalAccount[] {
  return readState().accounts.filter((account) => !tag || account.tag === tag);
}

export function putOperation(operation: LocalOperation): void {
  update((state) => {
    const index = state.operations.findIndex((item) => item.id === operation.id);
    if (operation.name === "post" && operation.post_fingerprint && operation.account_id) {
      state.post_intents ??= {};
      state.post_intents[postIntentKey(operation.account_id, operation.post_fingerprint)] = {
        operation_id: operation.id, status: operation.status, created_at: operation.created_at,
        updated_at: operation.updated_at, owner_pid: operation.owner_pid,
        error: operation.error, error_code: operation.error_code, result: operation.result,
      };
    }
    if (index >= 0) state.operations[index] = operation;
    else state.operations.push(operation);
    if (state.operations.length > 2_000) state.operations.splice(0, state.operations.length - 2_000);
  });
}

export function getOperation(id: string): LocalOperation | undefined {
  return readState().operations.find((operation) => operation.id === id);
}

export function listOperations(): LocalOperation[] {
  return readState().operations;
}

export function readMetrics(): StoredMetric[] {
  return readState().metrics;
}

export function appendMetrics(rows: StoredMetric[]): void {
  if (!rows.length) return;
  update((state) => {
    state.metrics.push(...rows);
    if (state.metrics.length > 50_000) state.metrics.splice(0, state.metrics.length - 50_000);
  });
}

export function readActions(accountId: string): ActionRecord[] {
  return readState().actions.filter((row) => row.account_id === accountId);
}

export function appendAction(accountId: string, operation: string): void {
  update((state) => {
    const cutoff = Date.now() - 48 * 60 * 60 * 1000;
    state.actions = state.actions.filter((row) => row.acted_at >= cutoff);
    state.actions.push({ account_id: accountId, operation, acted_at: Date.now() });
  });
}


interface PostIntentEntry {
  operation_id: string;
  status: OperationStatus;
  created_at: string;
  updated_at: string;
  owner_pid?: number;
  error?: string;
  error_code?: string;
  result?: unknown;
}

function postIntentKey(accountId: string, fingerprint: string): string {
  return createHash("sha256").update(rateLimitAccountKey(accountId) + "\n" + fingerprint).digest("hex");
}

function postOwnerAlive(pid: number | undefined): boolean {
  if (!pid || !Number.isInteger(pid) || pid <= 0) return false;
  if (pid === process.pid) return true;
  try { process.kill(pid, 0); return true; }
  catch (error: any) { return error?.code !== "ESRCH"; }
}

/** A durable cross-process post-intent claim. Crashed owner or ambiguous
 * result never triggers another external post for the same media/fields.
 * Explicit pre-dispatch failures can be requested again without guesswork.
 */
export function reserveTikTokPostOperation(candidate: LocalOperation, fingerprint: string):
  { operation: LocalOperation; reused: boolean } {
  if (!candidate.account_id || candidate.name !== "post") throw new Error("Post intent requires an account and post operation");
  const key = postIntentKey(candidate.account_id, fingerprint);
  let outcome!: { operation: LocalOperation; reused: boolean };
  update((state) => {
    state.post_intents ??= {};
    const previous = state.post_intents[key];
    // Never repeat a click whose acknowledgement may have been lost. Only
    // failures known to occur before browser mutation are retryable.
    const safeRetry = previous?.status === "failed" &&
      ["LAUNCH_FAILED", "RATE_LIMITED_PROTECTIVE"].includes(previous.error_code || "");
    const ageMs = previous ? Date.now() - Date.parse(previous.created_at) : 0;
    if (previous && !safeRetry && Number.isFinite(ageMs) && ageMs >= 0 && ageMs < 24 * 3_600_000) {
      let operation = state.operations.find((item) => item.id === previous.operation_id);
      if (!operation) {
        operation = { id: previous.operation_id, name: "post", account_id: candidate.account_id,
          status: previous.status, input: {}, created_at: previous.created_at,
          updated_at: previous.updated_at, owner_pid: previous.owner_pid,
          post_fingerprint: fingerprint, error: previous.error,
          error_code: previous.error_code, result: previous.result };
        state.operations.push(operation);
        if (state.operations.length > 2_000) state.operations.splice(0, state.operations.length - 2_000);
      }
      if (["pending", "running"].includes(operation.status) && !postOwnerAlive(previous.owner_pid)) {
        operation.status = "failed";
        operation.error_code = "UNCERTAIN";
        operation.error = "Previous TikTok post may have been submitted before its process exited. Verify on TikTok manually; duplicate post blocked.";
        operation.updated_at = new Date().toISOString();
        state.post_intents[key] = { ...previous, status: "failed", error_code: operation.error_code,
          error: operation.error, updated_at: operation.updated_at };
      }
      if (operation.status === "failed" && !["LAUNCH_FAILED", "RATE_LIMITED_PROTECTIVE", "UNCERTAIN"].includes(operation.error_code || "")) {
        operation.error_code = "UNCERTAIN";
        operation.error = "A previous identical post returned an unverified failure. Check TikTok manually before retrying; duplicate submission blocked.";
        operation.updated_at = new Date().toISOString();
        state.post_intents[key] = { ...previous, status: "failed", error_code: operation.error_code,
          error: operation.error, updated_at: operation.updated_at };
      }
      outcome = { operation: { ...operation }, reused: true };
      return;
    }
    const operation: LocalOperation = { ...candidate, post_fingerprint: fingerprint, owner_pid: process.pid };
    state.operations.push(operation);
    if (state.operations.length > 2_000) state.operations.splice(0, state.operations.length - 2_000);
    state.post_intents[key] = { operation_id: operation.id, status: operation.status,
      created_at: operation.created_at, updated_at: operation.updated_at,
      owner_pid: operation.owner_pid };
    outcome = { operation, reused: false };
  });
  return outcome;
}

/** Cross-process atomic reservation. Every admitted operation consumes one
 * slot before it can click a mutating control; even a crash/ambiguous result
 * cannot silently refund the attempt. The state lock protects check + write.
 * A browser/profile lock also remains held by the caller while operating.
 */
// Browser profile paths sanitize account IDs; key budgets by the same effective
// profile name so aliases cannot accidentally obtain independent quotas.
function rateLimitAccountKey(accountId: string): string {
  const key = accountId.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80).toLowerCase();
  if (!key) throw new Error("Invalid TikTok rate-limit account ID");
  return key;
}

type RateGate = { ok: boolean; reason?: string; retry_after_ms?: number };

function assessTikTokAction(state: LocalState, key: string, operation: string, now: number): RateGate {
  const cooldownMs = Math.max(0, Number(state.cooldowns?.[key] || 0) - now);
  if (cooldownMs > 0) {
    return { ok: false, reason: "TikTok has requested a cooldown for this account.", retry_after_ms: cooldownMs };
  }
  const rows = state.actions.filter((row) => rateLimitAccountKey(row.account_id) === key)
    .sort((a, b) => b.acted_at - a.acted_at);
  const sinceLast = rows.length ? now - rows[0].acted_at : Infinity;
  if (sinceLast < 30_000) {
    return { ok: false, reason: "Wait 30 seconds between account actions.", retry_after_ms: 30_000 - sinceLast };
  }
  const rule = operation === "post" ? { max: 3, ms: 86_400_000 } :
    operation === "follow" ? { max: 20, ms: 3_600_000 } :
    operation === "like" ? { max: 60, ms: 3_600_000 } : null;
  if (rule) {
    const counted = rows.filter((row) => row.operation === operation && row.acted_at > now - rule.ms);
    if (counted.length >= rule.max) {
      const oldest = Math.min(...counted.map((row) => row.acted_at));
      return { ok: false, reason: "Protective account cap reached (" + rule.max + " " + operation + " attempts).",
        retry_after_ms: Math.max(1, oldest + rule.ms - now) };
    }
  }
  return { ok: true };
}

/** Read-only best-effort preflight; never consumes a reservation. */
export function previewTikTokAction(accountId: string, operation: string): RateGate {
  return assessTikTokAction(readState(), rateLimitAccountKey(accountId), operation, Date.now());
}

export function reserveTikTokAction(accountId: string, operation: string): RateGate {
  const key = rateLimitAccountKey(accountId);
  let result: RateGate = { ok: false };
  update((state) => {
    const now = Date.now();
    result = assessTikTokAction(state, key, operation, now);
    if (!result.ok) return;
    state.actions = state.actions.filter((row) => row.acted_at > now - 48 * 3_600_000);
    state.actions.push({ account_id: key, operation, acted_at: now });
  });
  return result;
}

/** Never launch a normal browser/read session while TikTok has asked to pause.
 * Login recovery explicitly opts out; mutations must still reserve separately.
 */
export function assertTikTokReadAllowed(accountId: string): void {
  const key = rateLimitAccountKey(accountId);
  const delay = Math.max(0, Number(readState().cooldowns?.[key] || 0) - Date.now());
  if (delay > 0) {
    const error = new Error("TikTok account is cooling down; wait about " + Math.ceil(delay / 1000) + " seconds before browsing.") as
      Error & { error_code: string; retry_after_ms: number };
    error.error_code = "RATE_LIMITED_PROTECTIVE";
    error.retry_after_ms = delay;
    throw error;
  }
}

/** Account-wide cooldown survives process restarts. Retry-After may be numeric
 * seconds or an HTTP date; unknown/malformed values use a conservative floor.
 */
export function markTikTokRateLimited(accountId: string, status: number, header?: string | null): void {
  const key = rateLimitAccountKey(accountId);
  const now = Date.now();
  let delay = status === 503 ? 30_000 : 60_000;
  if (header) {
    const value = header.trim();
    const seconds = /^\d+(?:\.\d+)?$/.test(value) ? Number(value) : NaN;
    const ms = Number.isFinite(seconds) ? seconds * 1000 : Date.parse(value) - now;
    if (Number.isFinite(ms) && ms >= 0) delay = Math.max(delay, ms);
  }
  delay = Math.min(delay, 24 * 3_600_000);
  update((state) => {
    state.cooldowns ??= {};
    state.cooldowns[key] = Math.max(Number(state.cooldowns[key] || 0), Date.now() + delay);
  });
}
