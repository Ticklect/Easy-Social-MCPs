import { chromium, type Browser, type BrowserContext, type Page } from "playwright";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { homedir } from "node:os";
import { spawn, type ChildProcess } from "node:child_process";
import { getAccount, profileDir } from "./store.js";
import { discoverOpenBrowserPort } from "./browser-discovery.js";
import { acquireFileLock } from "./file-lock.js";
import { markTikTokRateLimited, assertTikTokReadAllowed } from "./social-rate-limit.js";

interface CountryProfile { locale: string; timezoneId: string }

const COUNTRY_PROFILES: Record<string, CountryProfile> = {
  us: { locale: "en-US", timezoneId: "America/New_York" },
  ca: { locale: "en-CA", timezoneId: "America/Toronto" },
  gb: { locale: "en-GB", timezoneId: "Europe/London" },
  au: { locale: "en-AU", timezoneId: "Australia/Sydney" },
  de: { locale: "de-DE", timezoneId: "Europe/Berlin" },
  fr: { locale: "fr-FR", timezoneId: "Europe/Paris" },
  es: { locale: "es-ES", timezoneId: "Europe/Madrid" },
  it: { locale: "it-IT", timezoneId: "Europe/Rome" },
  nl: { locale: "nl-NL", timezoneId: "Europe/Amsterdam" },
  br: { locale: "pt-BR", timezoneId: "America/Sao_Paulo" },
  mx: { locale: "es-MX", timezoneId: "America/Mexico_City" },
  jp: { locale: "ja-JP", timezoneId: "Asia/Tokyo" },
  kr: { locale: "ko-KR", timezoneId: "Asia/Seoul" },
  in: { locale: "en-IN", timezoneId: "Asia/Kolkata" },
  id: { locale: "id-ID", timezoneId: "Asia/Jakarta" },
  ph: { locale: "en-PH", timezoneId: "Asia/Manila" },
  sg: { locale: "en-SG", timezoneId: "Asia/Singapore" },
  ae: { locale: "en-AE", timezoneId: "Asia/Dubai" },
  sa: { locale: "ar-SA", timezoneId: "Asia/Riyadh" },
};

export function profileForCountry(country?: string): CountryProfile {
  return COUNTRY_PROFILES[(country || "us").toLowerCase()] || COUNTRY_PROFILES.us;
}

const accountLocks = new Map<string, Promise<void>>();

async function lockAccount(accountId: string): Promise<() => void> {
  const previous = accountLocks.get(accountId) || Promise.resolve();
  let release!: () => void;
  const current = new Promise<void>((resolve) => { release = resolve; });
  const tail = previous.then(() => current);
  accountLocks.set(accountId, tail);
  await previous;
  let releaseFileLock: (() => void) | undefined;
  try {
    releaseFileLock = await acquireFileLock(`${profileDir(accountId)}.lock`, { timeoutMs: 30_000, pollMs: 50 });
  } catch (error) {
    release();
    if (accountLocks.get(accountId) === tail) accountLocks.delete(accountId);
    throw error;
  }
  return () => {
    try { releaseFileLock?.(); } finally {
      release();
      if (accountLocks.get(accountId) === tail) accountLocks.delete(accountId);
    }
  };
}

function defaultHeadless(): boolean {
  if (process.env.TIKTOK_HEADLESS === "true") return true;
  if (process.env.TIKTOK_HEADLESS === "false") return false;
  return process.platform === "linux" && !process.env.DISPLAY;
}

function installedBrowser(): string | undefined {
  const candidates: string[] = [];
  if (process.platform === "win32") {
    const programFiles = process.env.PROGRAMFILES || "C:\\Program Files";
    const programFiles86 = process.env["PROGRAMFILES(X86)"] || "C:\\Program Files (x86)";
    const local = process.env.LOCALAPPDATA;
    candidates.push(
      join(programFiles, "imput", "Helium", "Application", "chrome.exe"),
      join(programFiles, "Helium", "Application", "chrome.exe"),
      join(programFiles, "Google", "Chrome", "Application", "chrome.exe"),
      join(programFiles86, "Google", "Chrome", "Application", "chrome.exe"),
      join(programFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
      join(programFiles86, "Microsoft", "Edge", "Application", "msedge.exe"),
    );
    if (local) candidates.push(
      join(local, "imput", "Helium", "Application", "chrome.exe"),
      join(local, "Programs", "Helium", "Application", "chrome.exe"),
      join(local, "Helium", "Application", "chrome.exe"),
      join(local, "Google", "Chrome", "Application", "chrome.exe"),
      join(local, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
    );
  } else if (process.platform === "darwin") {
    candidates.push(
      "/Applications/Helium.app/Contents/MacOS/Helium",
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
      "/Applications/Chromium.app/Contents/MacOS/Chromium",
    );
  } else {
    candidates.push(
      "/usr/bin/helium", "/usr/local/bin/helium",
      "/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/usr/bin/chromium",
      "/usr/bin/chromium-browser", "/usr/bin/microsoft-edge", "/usr/bin/brave-browser",
    );
  }
  return candidates.find((candidate) => existsSync(candidate));
}

type VirtualDisplay = { display: string; process: ChildProcess };

async function startVirtualDisplay(): Promise<VirtualDisplay> {
  const executable = ["/usr/bin/Xvfb", "/usr/local/bin/Xvfb"].find((candidate) => existsSync(candidate));
  if (!executable) {
    throw new Error(
      "TikTok QR login needs a headed browser. This Linux host has no DISPLAY or Xvfb; install it with `sudo apt-get install -y xvfb`.",
    );
  }
  const number = Array.from({ length: 40 }, (_, index) => 90 + index)
    .find((candidate) => !existsSync(`/tmp/.X11-unix/X${candidate}`));
  if (number === undefined) throw new Error("No free Xvfb display is available for TikTok QR login");
  const display = `:${number}`;
  const child = spawn(executable, [display, "-screen", "0", "1440x900x24", "-nolisten", "tcp"], {
    stdio: "ignore",
    windowsHide: true,
  });
  let spawnError: Error | undefined;
  child.once("error", (error) => { spawnError = error; });
  for (let attempt = 0; attempt < 30; attempt++) {
    if (existsSync(`/tmp/.X11-unix/X${number}`)) return { display, process: child };
    if (spawnError || child.exitCode !== null) break;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  child.kill();
  throw new Error(`Xvfb did not start for TikTok QR login${spawnError ? `: ${spawnError.message}` : ""}`);
}


/** The shared extension bridge currently proxies tab-level CDP only. Playwright
 * requires browser Target.* commands, so connect only to a complete local
 * Chromium debugger rather than incorrectly treating that bridge as a browser.
 */
function companionKeyFile(): string {
  const base = process.platform === "win32"
    ? process.env.LOCALAPPDATA || process.env.APPDATA || homedir()
    : process.platform === "darwin"
      ? join(homedir(), "Library", "Application Support")
      : process.env.XDG_DATA_HOME || join(homedir(), ".local", "share");
  return join(base, "ChatOnSteroids", "EasySocialBrowserBridge", "pairing-key");
}

export async function findUsableExistingBrowserPort(): Promise<number | null> {
  const explicit = existingBrowserPort();
  if (explicit) return explicit;
  return discoverOpenBrowserPort();
}

export async function shouldReuseExistingBrowser(): Promise<boolean> {
  return existingBrowserConfigured() || Boolean(await discoverOpenBrowserPort());
}

export function existingBrowserConfigured(): boolean {
  return Boolean(process.env.EASY_SOCIAL_BROWSER_DEBUG_PORT) ||
    existsSync(companionKeyFile()) ||
    process.env.EASY_SOCIAL_BROWSER_MODE === "existing";
}

function existingBrowserPort(): number | null {
  const raw = process.env.EASY_SOCIAL_BROWSER_DEBUG_PORT;
  if (raw === undefined || raw === "") return null;
  if (!/^[1-9][0-9]{0,4}$/.test(raw) || Number(raw) > 65535) {
    throw new Error("EASY_SOCIAL_BROWSER_DEBUG_PORT must be a localhost port (1-65535).");
  }
  return Number(raw);
}

async function debuggerWebSocket(port: number): Promise<string> {
  const response = await fetch("http://127.0.0.1:" + port + "/json/version", {
    signal: AbortSignal.timeout(3000),
  });
  if (!response.ok) throw new Error("The selected browser debugger is unavailable.");
  const details = await response.json() as { webSocketDebuggerUrl?: unknown };
  if (typeof details.webSocketDebuggerUrl !== "string") {
    throw new Error("The selected browser did not expose a Chromium debugger.");
  }
  const ws = new URL(details.webSocketDebuggerUrl);
  if (ws.protocol !== "ws:" || ws.hostname !== "127.0.0.1" || ws.port !== String(port) ||
      ws.username || ws.password || ws.search || ws.hash ||
      !ws.pathname.startsWith("/devtools/browser/") ||
      !/^[a-zA-Z0-9-]+$/.test(ws.pathname.slice("/devtools/browser/".length))) {
    throw new Error("The selected debugger returned an unsafe browser endpoint.");
  }
  return ws.toString();
}

/** Reads only the public profile link from our own TikTok tab. */
export async function signedInProfileName(page: Page): Promise<string | null> {
  const profile = page.locator('a[data-e2e="nav-profile"]').first();
  if (!await profile.isVisible({ timeout: 10_000 }).catch(() => false)) return null;
  const href = await profile.getAttribute("href", { timeout: 5_000 }).catch(() => null);
  if (!href) return null;
  try {
    const url = new URL(href, "https://www.tiktok.com");
    if (url.origin !== "https://www.tiktok.com") return null;
    return /^\/@([A-Za-z0-9._]{2,24})\/?$/.exec(url.pathname)?.[1] || null;
  } catch { return null; }
}

export interface LaunchLocalContextOptions {
  accountId: string;
  externalBrowserPort?: number;
  /** Login rebinds the account identity after checking the signed-in profile. */
  skipAccountIdentityCheck?: boolean;
  /** QR login recovery is explicitly allowed even during an account cooldown. */
  bypassCooldown?: boolean;
  country?: string;
  cookies?: any[];
  headless?: boolean;
  loadMedia?: boolean;
  /** Keep a headed login browser out of the operator's way; VPSes use Xvfb. */
  background?: boolean;
}

export interface LocalContext {
  browser: Browser | null;
  ctx: BrowserContext;
  page: Page;
  close: () => Promise<void>;
}

export async function launchLocalContext(opts: LaunchLocalContextOptions): Promise<LocalContext> {
  // Fast fail before browser startup and recheck after waiting on the profile
  // lock, since a different process may have received 429 in the meantime.
  if (!opts.bypassCooldown) assertTikTokReadAllowed(opts.accountId);
  const release = await lockAccount(opts.accountId);
  try { if (!opts.bypassCooldown) assertTikTokReadAllowed(opts.accountId); }
  catch (error) { release(); throw error; }
  let externalPort: number | null;
  try { externalPort = opts.externalBrowserPort || await findUsableExistingBrowserPort(); }
  catch (error) { release(); throw error; }
  if (externalPort && opts.accountId !== "default") {
    release();
    throw new Error('Existing browser mode supports only account_id "default".');
  }
  if (!externalPort && existingBrowserConfigured()) {
    release();
    throw new Error("TikTok Easy cannot attach Playwright to the tab-only Easy Social browser companion. Reuse your signed-in Chromium or Helium window with an existing local CDP debugger through EASY_SOCIAL_BROWSER_DEBUG_PORT; no browser or profile was launched.");
  }
  const profile = profileForCountry(opts.country);
  const headless = opts.headless ?? defaultHeadless();
  let virtualDisplay: VirtualDisplay | undefined;
  if (!externalPort && !headless && process.platform === "linux" && !process.env.DISPLAY) {
    try { virtualDisplay = await startVirtualDisplay(); }
    catch (error) { release(); throw error; }
  }
  const launchOptions: any = {
    headless,
    locale: profile.locale,
    timezoneId: profile.timezoneId,
    viewport: { width: 1440, height: 900 },
    args: [
      "--no-first-run", "--no-default-browser-check",
      ...(opts.background && !virtualDisplay ? ["--start-minimized"] : []),
    ],
  };
  if (virtualDisplay) {
    launchOptions.env = {
      ...Object.fromEntries(Object.entries(process.env).filter((entry): entry is [string, string] => entry[1] !== undefined)),
      DISPLAY: virtualDisplay.display,
    };
  }
  const browserPath = process.env.TIKTOK_BROWSER_PATH || installedBrowser();
  if (browserPath) launchOptions.executablePath = browserPath;
  else if (process.env.TIKTOK_BROWSER_CHANNEL) launchOptions.channel = process.env.TIKTOK_BROWSER_CHANNEL;

  let ctx: BrowserContext;
  let externalBrowser: Browser | undefined;
  try {
    if (externalPort) {
      const ws = await debuggerWebSocket(externalPort);
      externalBrowser = await chromium.connectOverCDP(ws, { timeout: 10_000 });
      if (externalBrowser.contexts().length !== 1) throw new Error("Multiple browser contexts are open; refusing to guess the signed-in account.");
      const originalContext = externalBrowser.contexts()[0];
      if (!originalContext) throw new Error("Connected browser has no persistent signed-in context.");
      ctx = originalContext;
    } else {
      ctx = await chromium.launchPersistentContext(profileDir(opts.accountId), launchOptions);
    }
  } catch (error) {
    await externalBrowser?.close().catch(() => {});
    virtualDisplay?.process.kill();
    release();
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(
      `${message}${externalPort ? " (Existing browser CDP connection failed; a separate profile was not opened.)" : '\nInstall Chromium with "npx playwright install chromium", or set TIKTOK_BROWSER_PATH to Helium/Chrome/Edge/Brave.'}`,
    );
  }

  try {
    if (externalBrowser && opts.cookies?.length) throw new Error("Cannot inject saved cookies into your existing browser.");
    if (opts.cookies?.length) {
      await ctx.addCookies(opts.cookies.map((cookie) => {
        const { expirationDate, expires, ...rest } = cookie;
        return { ...rest, ...((expirationDate || expires) > 0 ? { expires: expirationDate || expires } : {}) };
      }));
    }
    const pages = ctx.pages();
    const page = externalBrowser ? await ctx.newPage() : pages[0] || await ctx.newPage();
    (page as any).__tiktokRateLimitAccountId = opts.accountId;
    page.on("response", (response) => {
      const status = response.status();
      if (status !== 429 && status !== 503) return;
      let host: string;
      try { host = new URL(response.url()).hostname.toLowerCase(); }
      catch { return; /* malformed response URL, not a persistence failure */ }
      if (host !== "tiktok.com" && !host.endsWith(".tiktok.com") &&
          host !== "tiktokv.com" && !host.endsWith(".tiktokv.com")) return;
      const persistFailure = (error: unknown) => {
        (page as any).__tiktokLimiterFailure = error;
        console.error("[tiktok] COOLDOWN PERSISTENCE FAILED; closing browser session to stop actions:", error);
        void page.close().catch(() => {});
      };
      try { markTikTokRateLimited(opts.accountId, status); }
      catch (error) { persistFailure(error); return; }
      void response.headerValue("retry-after").then((header) => {
        if (!header) return;
        try { markTikTokRateLimited(opts.accountId, status, header); }
        catch (error) { persistFailure(error); }
      }).catch(() => {}); // fallback cooldown was already persisted
    });
    trackPendingRequests(page);
    await blockHeavyResources(page, opts.loadMedia === true);
    if (externalBrowser && !opts.skipAccountIdentityCheck) {
      const bound = getAccount(opts.accountId)?.browser_profile_name;
      if (!bound) throw new Error("Existing browser TikTok identity has not been verified. Run tiktok_login to bind the signed-in account first.");
      await page.goto("https://www.tiktok.com/", { waitUntil: "domcontentloaded", timeout: 60_000 });
      const actual = await signedInProfileName(page);
      if (!actual || actual.toLowerCase() !== bound.toLowerCase()) {
        throw new Error("Connected TikTok account differs from the account previously verified. Run tiktok_login again before any action.");
      }
    }
    let closed = false;
    return {
      browser: ctx.browser(),
      ctx,
      page,
      close: async () => {
        if (closed) return;
        closed = true;
        try { if (externalBrowser) { await page.close(); await externalBrowser.close(); } else await ctx.close(); } finally {
          virtualDisplay?.process.kill();
          release();
        }
      },
    };
  } catch (error) {
    if (externalBrowser) await externalBrowser.close().catch(() => {});
    else await ctx.close().catch(() => {});
    virtualDisplay?.process.kill();
    release();
    throw error;
  }
}

export interface OpenSessionOptions {
  accountId: string;
  proxySessionId?: string;
  cookies: any[];
  country?: string;
  headless?: boolean;
  loadMedia?: boolean;
}

export async function openAuthenticatedSession(opts: OpenSessionOptions): Promise<LocalContext> {
  return launchLocalContext({
    accountId: opts.accountId,
    country: opts.country,
    cookies: opts.cookies,
    headless: opts.headless,
    loadMedia: opts.loadMedia,
  });
}

const MAX_TRACKED = 300;

function trackPendingRequests(page: Page): void {
  const pending = new Map<any, { url: string; method: string; resourceType: string; startedAt: number }>();
  (page as any).__tiktokPending = pending;
  page.on("request", (request) => {
    if (pending.size >= MAX_TRACKED) pending.delete(pending.keys().next().value);
    pending.set(request, {
      url: request.url().slice(0, 300),
      method: request.method(),
      resourceType: request.resourceType(),
      startedAt: Date.now(),
    });
  });
  const done = (request: any) => pending.delete(request);
  page.on("requestfinished", done);
  page.on("requestfailed", done);
}

export function pendingRequests(page: Page, limit = 12): Array<{ url: string; method: string; resourceType: string; ageMs: number }> {
  const pending: Map<any, any> | undefined = (page as any).__tiktokPending;
  if (!pending) return [];
  const now = Date.now();
  return [...pending.values()]
    .map((item) => ({ ...item, ageMs: now - item.startedAt }))
    .sort((a, b) => b.ageMs - a.ageMs)
    .slice(0, limit);
}

async function blockHeavyResources(page: Page, loadMedia: boolean): Promise<void> {
  await page.route("**/*", async (route) => {
    const request = route.request();
    if (!loadMedia && ["image", "media", "font"].includes(request.resourceType())) {
      await route.abort().catch(() => {});
      return;
    }
    await route.continue().catch(() => {});
  });
}
