import { appendAction, readActions, previewTikTokAction, reserveTikTokAction, markTikTokRateLimited, assertTikTokReadAllowed } from "./store.js";

export interface RateLimitResult { ok: boolean; reason?: string; retry_after_ms?: number }

const MIN_SPACING_MS = 30_000;
const WINDOWS: Array<{ operations: string[]; windowMs: number; max: number }> = [
  { operations: ["post"], windowMs: 24 * 60 * 60 * 1000, max: 3 },
  { operations: ["follow"], windowMs: 60 * 60 * 1000, max: 20 },
  { operations: ["like"], windowMs: 60 * 60 * 1000, max: 60 },
];

export function checkRateLimit(accountId: string, _platform: "tiktok", operation: string): RateLimitResult {
  return previewTikTokAction(accountId, operation);
}

export function recordAction(accountId: string, _platform: "tiktok", operation: string): void {
  appendAction(accountId, operation);
}

/** Preflight checks do not reserve capacity; only the mutation gate does. */
export function reserveAction(accountId: string, _platform: "tiktok", operation: string): RateLimitResult {
  return reserveTikTokAction(accountId, operation);
}
export { markTikTokRateLimited, assertTikTokReadAllowed };
