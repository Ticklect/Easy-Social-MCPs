import { randomUUID } from "node:crypto";
import { mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

type LockOptions = { timeoutMs?: number; pollMs?: number };
const syncWait = new Int32Array(new SharedArrayBuffer(4));
const PROCESS_INSTANCE_ID = randomUUID().replaceAll("-", "");

function ownerPath(lockDir: string): string {
  return join(lockDir, "owner.json");
}

function reclaimRootPath(lockDir: string): string {
  return `${lockDir}.reaping`;
}

const OWNERLESS_GRACE_MS = 30_000;
const RECLAIM_CLAIM_STALE_MS = 5_000;

function ownerPid(lockDir: string): number | null {
  try {
    const parsed = JSON.parse(readFileSync(ownerPath(lockDir), "utf8")) as { pid?: unknown };
    const pid = Number(parsed.pid);
    return Number.isInteger(pid) && pid > 0 ? pid : null;
  } catch {
    return null;
  }
}

function isProcessAlive(pid: number): boolean {
  if (pid === process.pid) return true;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error: any) {
    return error?.code !== "ESRCH";
  }
}

function reclaimInProgress(lockDir: string): boolean {
  const root = reclaimRootPath(lockDir);
  let claims;
  try {
    claims = readdirSync(root, { withFileTypes: true });
  } catch (error: any) {
    if (error?.code === "ENOENT") return false;
    return true;
  }
  let active = false;
  for (const claim of claims) {
    if (!claim.isDirectory()) { active = true; continue; }
    const claimPath = join(root, claim.name);
    let expired = false;
    try { expired = Date.now() - statSync(claimPath).mtimeMs >= RECLAIM_CLAIM_STALE_MS; }
    catch { continue; }
    if (expired) {
      try { rmSync(claimPath, { recursive: true, force: true }); }
      catch { active = true; }
      continue;
    }
    const match = /^(\d+)-([0-9a-f]{32})-/.exec(claim.name);
    const pid = Number(match?.[1]);
    const processInstanceId = match?.[2];
    if (!Number.isInteger(pid) || pid <= 0 || !processInstanceId) { active = true; continue; }
    if (pid !== process.pid && isProcessAlive(pid)) { active = true; continue; }
    if (pid === process.pid && processInstanceId === PROCESS_INSTANCE_ID) { active = true; continue; }
    try { rmSync(claimPath, { recursive: true, force: true }); }
    catch { active = true; }
  }
  return active;
}

function createReclaimClaim(lockDir: string): string {
  const root = reclaimRootPath(lockDir);
  mkdirSync(root, { recursive: true, mode: 0o700 });
  const claimDir = join(root, `${process.pid}-${PROCESS_INSTANCE_ID}-${randomUUID()}`);
  mkdirSync(claimDir, { mode: 0o700 });
  return claimDir;
}

function oldEnoughToReapOwnerless(lockDir: string): boolean {
  try { return Date.now() - statSync(lockDir).mtimeMs >= OWNERLESS_GRACE_MS; }
  catch { return false; }
}

function tryAcquire(lockDir: string): boolean {
  mkdirSync(dirname(lockDir), { recursive: true, mode: 0o700 });
  if (reclaimInProgress(lockDir)) return false;
  try {
    mkdirSync(lockDir, { mode: 0o700 });
  } catch (error: any) {
    if (error?.code === "EEXIST" || error?.code === "EPERM") return false;
    throw error;
  }
  if (reclaimInProgress(lockDir)) {
    try { rmSync(lockDir, { recursive: true, force: true }); } catch {}
    return false;
  }
  try {
    writeFileSync(ownerPath(lockDir), JSON.stringify({ pid: process.pid }), { flag: "wx", mode: 0o600 });
    return true;
  } catch (error) {
    try { rmSync(lockDir, { recursive: true, force: true }); } catch {}
    throw error;
  }
}

function reapDeadOwner(lockDir: string): void {
  const initialPid = ownerPid(lockDir);
  if (initialPid !== null ? isProcessAlive(initialPid) : !oldEnoughToReapOwnerless(lockDir)) return;
  const claimDir = createReclaimClaim(lockDir);
  try {
    const currentPid = ownerPid(lockDir);
    if (currentPid !== null ? isProcessAlive(currentPid) : !oldEnoughToReapOwnerless(lockDir)) return;
    const quarantinePath = join(claimDir, "lock");
    try { renameSync(lockDir, quarantinePath); }
    catch (error: any) {
      if (["ENOENT", "EPERM", "EACCES", "EBUSY"].includes(error?.code)) return;
      throw error;
    }
  } finally {
    try { rmSync(claimDir, { recursive: true, force: true }); } catch {}
  }
}

function releaseLock(lockDir: string): void {
  try {
    const parsed = JSON.parse(readFileSync(ownerPath(lockDir), "utf8")) as { pid?: unknown };
    if (Number(parsed.pid) !== process.pid) return;
  } catch {
    return;
  }
  rmSync(lockDir, { recursive: true, force: true });
}

export function acquireFileLockSync(lockDir: string, options: LockOptions = {}): () => void {
  const timeoutMs = options.timeoutMs ?? 10_000;
  const pollMs = options.pollMs ?? 25;
  const deadline = Date.now() + timeoutMs;
  while (true) {
    if (tryAcquire(lockDir)) return () => releaseLock(lockDir);
    reapDeadOwner(lockDir);
    if (Date.now() >= deadline) throw new Error(`Timed out waiting for TikTok Easy lock: ${lockDir}`);
    Atomics.wait(syncWait, 0, 0, pollMs);
  }
}

export async function acquireFileLock(lockDir: string, options: LockOptions = {}): Promise<() => void> {
  const timeoutMs = options.timeoutMs ?? 30_000;
  const pollMs = options.pollMs ?? 50;
  const deadline = Date.now() + timeoutMs;
  while (true) {
    if (tryAcquire(lockDir)) return () => releaseLock(lockDir);
    reapDeadOwner(lockDir);
    if (Date.now() >= deadline) throw new Error(`Timed out waiting for TikTok Easy lock: ${lockDir}`);
    await new Promise((resolve) => setTimeout(resolve, pollMs));
  }
}

export function withFileLockSync<T>(lockDir: string, fn: () => T, options: LockOptions = {}): T {
  const release = acquireFileLockSync(lockDir, options);
  try { return fn(); } finally { release(); }
}
