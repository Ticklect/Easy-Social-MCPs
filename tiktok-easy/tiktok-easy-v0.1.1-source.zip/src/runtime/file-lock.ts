import { mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

type LockOptions = { timeoutMs?: number; pollMs?: number };
const syncWait = new Int32Array(new SharedArrayBuffer(4));

function ownerPath(lockDir: string): string {
  return join(lockDir, "owner.json");
}

const OWNERLESS_GRACE_MS = 30_000;

function ownerPid(lockDir: string): number | null {
  try {
    const parsed = JSON.parse(readFileSync(ownerPath(lockDir), "utf8")) as { pid?: unknown };
    const pid = Number(parsed.pid);
    return Number.isInteger(pid) && pid > 0 ? pid : null;
  } catch {
    return null;
  }
}

function isProcessAlive(pid: number): boolean {
  if (pid === process.pid) return true;
  try {
    process.kill(pid, 0);
    return true;
  } catch (error: any) {
    return error?.code !== "ESRCH";
  }
}

function oldEnoughToReapOwnerless(lockDir: string): boolean {
  try { return Date.now() - statSync(lockDir).mtimeMs >= OWNERLESS_GRACE_MS; }
  catch { return false; }
}

function tryAcquire(lockDir: string): boolean {
  mkdirSync(dirname(lockDir), { recursive: true, mode: 0o700 });
  try {
    mkdirSync(lockDir, { mode: 0o700 });
  } catch (error: any) {
    if (error?.code === "EEXIST") return false;
    throw error;
  }
  try {
    writeFileSync(ownerPath(lockDir), JSON.stringify({ pid: process.pid }), { flag: "wx", mode: 0o600 });
    return true;
  } catch (error) {
    try { rmSync(lockDir, { recursive: true, force: true }); } catch {}
    throw error;
  }
}

function reapDeadOwner(lockDir: string): void {
  const pid = ownerPid(lockDir);
  if (pid !== null ? isProcessAlive(pid) : !oldEnoughToReapOwnerless(lockDir)) return;
  try { rmSync(lockDir, { recursive: true, force: true }); } catch {}
}

function releaseLock(lockDir: string): void {
  try {
    const parsed = JSON.parse(readFileSync(ownerPath(lockDir), "utf8")) as { pid?: unknown };
    if (Number(parsed.pid) !== process.pid) return;
  } catch {
    return;
  }
  rmSync(lockDir, { recursive: true, force: true });
}

export function acquireFileLockSync(lockDir: string, options: LockOptions = {}): () => void {
  const timeoutMs = options.timeoutMs ?? 10_000;
  const pollMs = options.pollMs ?? 25;
  const deadline = Date.now() + timeoutMs;
  while (true) {
    if (tryAcquire(lockDir)) return () => releaseLock(lockDir);
    reapDeadOwner(lockDir);
    if (Date.now() >= deadline) throw new Error(`Timed out waiting for TikTok Easy lock: ${lockDir}`);
    Atomics.wait(syncWait, 0, 0, pollMs);
  }
}

export async function acquireFileLock(lockDir: string, options: LockOptions = {}): Promise<() => void> {
  const timeoutMs = options.timeoutMs ?? 30_000;
  const pollMs = options.pollMs ?? 50;
  const deadline = Date.now() + timeoutMs;
  while (true) {
    if (tryAcquire(lockDir)) return () => releaseLock(lockDir);
    reapDeadOwner(lockDir);
    if (Date.now() >= deadline) throw new Error(`Timed out waiting for TikTok Easy lock: ${lockDir}`);
    await new Promise((resolve) => setTimeout(resolve, pollMs));
  }
}

export function withFileLockSync<T>(lockDir: string, fn: () => T, options: LockOptions = {}): T {
  const release = acquireFileLockSync(lockDir, options);
  try { return fn(); } finally { release(); }
}
