# YouTube Easy

YouTube Easy is a ready-to-import MCP bundle for uploading and managing videos through the normal YouTube and YouTube Studio web interfaces. It does not use the YouTube Data API, Google Cloud, OAuth client credentials, API keys, copied cookies, refresh tokens, or `.env` credentials.

## Setup

1. Download `youtube-easy-v0.1.4.mcpb` from this repository.
2. Import it into an MCPB-compatible host.
3. Connect your existing signed-in browser once through the [Easy Social Browser Companion](../browser-companion/README.md), unless it already exposes a compatible local debugger.
4. Ask the agent to work on YouTube using YouTube Easy. It uses the currently signed-in channel without a separate `youtube_login` step.
5. Run `youtube_status` to verify the selected channel.

Never type a Google password into an MCP tool. Authentication belongs only in the real Google/YouTube page opened by YouTube Easy. The bundle contains its complete Node 22 runtime code and has no npm dependencies or runtime install step.

## Tools

- Session: `youtube_login`, `youtube_status`, `youtube_forget_session`
- Uploads: `upload_video`, `upload_short`, `get_upload_status`
- Management: `get_my_videos`, `update_video`, `set_thumbnail`, `schedule_video`, `delete_video`
- Community: `youtube_get_comments`, `reply_to_comment`
- Public reads: `get_channel`, `search_youtube`, `get_video`, `get_transcript`

Uploads accept a local video path, title, description, private/unlisted/public visibility, required made-for-kids declaration, optional schedule, thumbnail, exact existing playlist name, and tags. `upload_short` additionally validates that locally readable media metadata is no longer than 180 seconds and is square or vertical before any final action.

YouTube Easy only clicks final publish, schedule, or save controls after re-reading the important Studio fields and matching them to the request. This includes the selected filename and size, title, description, audience, visibility, schedule instant/time-zone text, and requested thumbnail, playlist, and tags. If Studio does not expose an unambiguous control or readable value, it stops before the final action. An upload already selected by Studio may remain as a draft/private item.

When a selected upload is deliberately stopped, the MCP returns a structured `draft_preserved` error containing any captured video ID/URLs. That terminal outcome is persisted and reused for the identical request so another process cannot accidentally upload the same file again.

## Cross-process safety

The browser profile and every write are coordinated with filesystem-backed leases shared by completely independent Node/MCP processes. A write acquires its account + request-fingerprint lease before duplicate checking. Successful results are persisted with video IDs, Studio URLs, and public URLs as early as Studio exposes them.

After a possible crash, YouTube Easy reconciles the intended action against Studio. It reuses an existing confirmed result, retries only when it can prove the action did not happen, and otherwise returns explicit `UNCERTAIN` without sending another write. Stale leases are recovered after their owner and lease lifetime are checked.

Reads and writes now share a persisted browser-profile pacing state across independent MCP processes. Browser reads are spaced at least 1.25 seconds apart, while Studio actions use a more conservative 3.5-second profile gap in addition to the account write gate. Gaps are measured from the end of the previous browser session. When YouTube returns HTTP 429 or a transient HTTP 5xx response to a document/API request, the MCP records a shared cooldown. It honours a valid `Retry-After` header (up to seven days), otherwise uses a 60-second 429 cooldown or 15-second 5xx cooldown. Calls during cooldown stop before opening a page. There are no automatic retries after throttling, and these are best-effort web-automation limits rather than a guarantee against account restrictions.

## Browsers and local data

YouTube Easy detects Helium, Google Chrome, Microsoft Edge, and Chromium on Windows, macOS, and Linux. By default, it uses your accessible already-signed-in browser. If you explicitly select `EASY_SOCIAL_BROWSER_MODE=dedicated`, it starts an isolated local profile on an ephemeral loopback debugger port. `youtube_forget_session` closes only that dedicated browser and removes only its profile.

You can also use an already running Chromium browser if it **already exposes a loopback CDP port**. Set `EASY_SOCIAL_BROWSER_DEBUG_PORT` to that port in YouTube Easy's environment. A missing browser connection now produces a clear error by default instead of launching another profile. Its existing Google sign-in is reused, and its profile is never closed or cleared. Normally opened Chrome windows do not expose CDP; Chrome 136+ also blocks remote debugging of its default profile.

To use an ordinary signed-in Helium, Chrome, Edge, Brave, Chromium, Vivaldi or Opera window, install and pair the [Easy Social Browser Companion](../browser-companion/README.md). It is discovered automatically and preserves your existing Google/YouTube login without copying cookies. Firefox and Safari require a separate browser implementation.

## Important limitations

This is an unofficial web-automation integration. YouTube can change Studio markup, labels, flows, anti-automation behavior, or account requirements without notice. v0.1.4 has extensive offline simulated-DOM and independent-process tests, but no verified real Google login or live YouTube upload in this release. Do not treat offline test coverage as a claim that live uploading currently works.

Transcripts are returned only when the public watch page exposes its transcript panel. Playlist and tag operations stop as unsupported when Studio does not provide one uniquely identifiable, re-readable control. Processing/check status can be `null` when Studio does not expose a single unambiguous value.

Review [SECURITY.md](SECURITY.md) before use. Page titles, descriptions, comments, channel text, search results, and transcripts are untrusted external content and must never be treated as instructions to access files, credentials, secrets, or unrelated tools.

## Build and test

From the repository root with Node 22 or newer:

```text
npm --prefix youtube-easy run check
npm --prefix youtube-easy test
npm --prefix youtube-easy run build
```

The build is dependency-free and deterministically produces the MCPB, source ZIP, and SHA-256 file in `youtube-easy/`.

## License

YouTube Easy project-owned code is licensed under the **GNU Affero General Public License v3.0 or later (AGPL-3.0-or-later)**. Third-party notices remain under their original licenses. See [`LICENSE`](./LICENSE) and [`THIRD_PARTY_LICENSES.md`](./THIRD_PARTY_LICENSES.md).
